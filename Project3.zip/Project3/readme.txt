C:\Program Files\MongoDB\Server\8.0\bin

C:\Program Files\mongosh